//
//  main.m
//  CC3DemoMultiScene
//
//  Created by Bill Hollings on 2014/01/16.
//  Copyright (c) 2014 The Brenwill Workshop Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
