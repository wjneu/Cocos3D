/**
 *  ___PROJECTNAMEASIDENTIFIER___Scene.h
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
 */


#import "CC3Scene.h"

/** A sample application-specific CC3Scene subclass.*/
@interface ___PROJECTNAMEASIDENTIFIER___Scene : CC3Scene {
}

@end
