/**
 *  ___PROJECTNAMEASIDENTIFIER___Layer.h
 *  ___PROJECTNAME___
 *
 *  Created by ___FULLUSERNAME___ on ___DATE___.
 *  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
 */


#import "CC3Layer.h"


/** A sample application-specific CC3Layer subclass. */
@interface ___PROJECTNAMEASIDENTIFIER___Layer : CC3Layer {
}

@end
