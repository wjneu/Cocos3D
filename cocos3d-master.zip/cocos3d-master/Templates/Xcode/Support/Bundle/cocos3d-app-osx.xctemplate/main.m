//
//  main.m
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "cocos2d.h"

int main(int argc, char* argv[]) {
	[CCGLView load_];
    return NSApplicationMain(argc, (const char**)argv);
}
